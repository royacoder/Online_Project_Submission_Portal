@echo off
echo =======================================================
echo Starting Online Project Submission Portal...
echo =======================================================
echo.

cd python_backend

echo [1] Activating virtual environment...
if NOT exist "venv" (
    echo Error: Virtual environment not found. Please run 'setup.bat' first.
    pause
    exit /b
)
call venv\Scripts\activate.bat

echo.
echo [2] Starting the Flask API server...
echo The application will be available at http://localhost:5000/
echo DO NOT CLOSE THIS WINDOW while using the application!
echo.
echo To stop the server, press CTRL+C.
echo.

:: Open the default browser after a short delay
start "" http://localhost:5000/

:: Start the Python server
python app.py

pause
