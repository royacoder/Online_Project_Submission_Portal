import urllib.request
import urllib.parse
import http.cookiejar

url = 'https://projectsubmissionbackend-3.onrender.com/api?action=login'
data = urllib.parse.urlencode({'email': 'admin@portal.com', 'password': 'admin123'}).encode()
cj = http.cookiejar.CookieJar()
opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
req = urllib.request.Request(url, data=data, method='POST')
req.add_header('Content-Type', 'application/x-www-form-urlencoded')

try:
    resp = opener.open(req)
    print('status', resp.status)
    print(resp.read().decode())
    print('cookies', [f'{c.name}={c.value}' for c in cj])
except urllib.error.HTTPError as e:
    print('status', e.code)
    print(e.read().decode())
except Exception as e:
    import traceback
    traceback.print_exc()
