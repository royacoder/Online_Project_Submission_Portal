# Deployment Guide: Vercel + Render + Supabase + Cloudinary

This guide shows the recommended deployment order and the exact setup for this project.

## 1. Prepare the backend for Render

### a. Add environment variables
Create a `.env` file in `python_backend/` from `.env.example`.

Required values:
- `SECRET_KEY` - strong random secret
- `CORS_ORIGINS` - frontend origin(s), e.g. `https://your-frontend.vercel.app`
- `SESSION_COOKIE_SAMESITE=None`
- `SESSION_COOKIE_SECURE=true`
- `DEBUG=false`
- `HOST=0.0.0.0`
- `PORT=5000`

Optional Cloudinary values:
- `CLOUDINARY_ENABLED=true`
- `CLOUDINARY_CLOUD_NAME`
- `CLOUDINARY_API_KEY`
- `CLOUDINARY_API_SECRET`

### b. Install dependencies locally
In `python_backend/` run:
```powershell
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

### c. Start locally for verification
```powershell
python app.py
```

If using Cloudinary, verify uploads work and the returned URLs are stored correctly.

### d. Render deployment settings
Create a new Render Web Service for the `python_backend/` folder.
- Environment: `Python 3.x`
- Build command: `pip install -r requirements.txt`
- Start command: `gunicorn app:app --bind 0.0.0.0:$PORT`
- Add render environment variables using the same keys from `.env`
- Set `CORS_ORIGINS` to your frontend URL

## 2. Deploy the frontend on Vercel

### a. Use the `frontend/` folder
Deploy only the `frontend/` directory as a static site.

### b. Configure runtime `config.json`
Copy `frontend/config.example.json` to `frontend/config.json` and update values:
- `API_URL`: `https://<your-backend>.onrender.com/api`
- `API_URL_BASE`: `https://<your-backend>.onrender.com`
- `FILES_BASE_URL`: `https://<your-backend>.onrender.com/uploads`

If you use Cloudinary, uploaded file links will already be full URLs.

### c. Verify static deployment
Open the frontend URL and confirm pages load without console errors.

## 3. Set up Supabase (database)

### a. Create a new Supabase project
- Create a free Supabase project
- Open the SQL Editor in Supabase
- Run `database/schema_postgres.sql` to create the app schema

### b. Connect the backend to Supabase
This repository now supports Supabase/Postgres by reading `DATABASE_URL` from environment variables.
The backend will use Supabase when `DATABASE_URL` is present, and falls back to local SQLite if not.

### c. Recommended setup path
1. Create a Supabase project.
2. Open the SQL Editor and run `database/schema_postgres.sql`.
3. Set your Supabase database URL in Render as `DATABASE_URL`.
4. Keep `CORS_ORIGINS` configured for your frontend URL.

### d. Notes
- The backend now uses `psycopg2` to connect to Postgres.
- `python_backend/.env.example` includes a sample `DATABASE_URL` line.
- The app still works locally with SQLite when `DATABASE_URL` is unset.

## 4. Configure Cloudinary for media storage

### a. Create a Cloudinary account
- Get `cloud_name`, `api_key`, and `api_secret`
- Set `CLOUDINARY_ENABLED=true` in Render
- Set `CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY`, `CLOUDINARY_API_SECRET`

### b. Confirm upload behavior
If Cloudinary is enabled, profile photos and project files are uploaded to Cloudinary and the app stores secure URLs in the DB.

## 5. Production checklist

- Backend accessible at `https://<your-backend>.onrender.com`
- Frontend config points to the backend
- CORS origin includes the frontend URL
- `SESSION_COOKIE_SAMESITE=None` and `SESSION_COOKIE_SECURE=true`
- Cloudinary credentials stored securely in Render
- Supabase DB migration completed when ready

## Notes
- `python_backend/requirements.txt` is now present for deployment
- `python_backend/Procfile` is included for process startup
- `frontend/config.example.json` is the runtime config template
- Local dev can still use `run.bat` and `setup.bat` if needed
