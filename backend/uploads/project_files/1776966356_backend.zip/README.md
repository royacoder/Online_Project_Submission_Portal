# Online Project Submission Portal (Python Backend)

This is a complete web application for managing student project submissions, team formations, and evaluations, now powered by **Python (Flask)** and **MySQL**.

## Role Hierarchy & Scope

The system features robust role-based access control with 4 primary roles: Admin, HOD, Guide, and Student.

## Technology Stack

*   **Frontend**: HTML5, CSS3, JavaScript, Bootstrap 5.3
*   **Backend**: Python 3 (Flask Framework)
*   **Database**: MySQL
*   **Server**: Flask (Development Server)

## Key Features

*   **RESTful API**: Python Flask implementation of the backend logic.
*   **Database Design**: Structured MySQL database.
*   **Authentication**: Session-based auth with `bcrypt` password hashing.
*   **File Management**: Secure file uploads for project deliverables.

## Setup Instructions

### 1. Database Setup
1. Ensure a MySQL server is running (e.g., via XAMPP or standalone MySQL).
2. Create a database named `online_project_submission`.
3. Import the `database/schema.sql` file into your MySQL server.

### 2. Backend Setup (Python)
1. Navigate to the `python_backend` directory.
2. The project uses a virtual environment:
   ```powershell
   cd python_backend
   .\venv\Scripts\activate
   ```
3. Install dependencies:
   ```powershell
   pip install -r requirements.txt
   ```
4. Start the backend server:
   ```powershell
   python app.py
   ```
   The server will run at `http://localhost:5000`.
   If `DATABASE_URL` is set in `python_backend/.env`, the backend connects to Supabase/Postgres instead of local SQLite.

### 3. Frontend Usage
Since the backend is now running on port 5000, you can open the frontend HTML files directly in a browser or serve them with any static web server.
*   For local dev, the frontend can still use `window.location.origin` by default.
*   For deployment, copy `frontend/config.example.json` to `frontend/config.json` and update `API_URL`, `API_URL_BASE`, and `FILES_BASE_URL`.

### 4. Deployment
This repository includes a `DEPLOYMENT.md` file with a step-by-step deployment guide for:
- `Vercel` for frontend static hosting
- `Render` for backend hosting
- `Cloudinary` for uploaded files
- `Supabase` for planned production database migration

See `DEPLOYMENT.md` for the full deployment order and environment setup.

### Default Credentials:
*   **Admin Email:** `admin@portal.com`
*   **Password:** `admin123`

## Workflows:
1. **Login as Admin** to create Departments and HODs.
2. **Students** can register and create solo or group teams.
3. **Guides** can review projects and provide evaluations.

