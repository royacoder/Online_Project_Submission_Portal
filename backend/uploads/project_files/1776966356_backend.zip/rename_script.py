import os

def replace_in_file(filepath, old_text, new_text):
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        new_content = content.replace(old_text, new_text)
        
        if content != new_content:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(new_content)
                print(f"Updated: {filepath}")
    except Exception as e:
        print(f"Error in {filepath}: {e}")

root_dir = r"c:\Users\user\Desktop\ONLINE PROJECT SUBMISSION PORTAL"
for root, dirs, files in os.walk(root_dir):
    for file in files:
        if file.endswith(('.html', '.py', '.js', '.css', '.md')):
            replace_in_file(os.path.join(root, file), "Submission Portal", "Submission Portal")
