@echo off
echo =======================================================
echo Starting Setup for Online Project Submission Portal...
echo =======================================================
echo.

cd python_backend

echo [1] Checking if virtual environment exists...
IF NOT EXIST venv (
    echo Creating virtual environment 'venv'...
    python -m venv venv
) ELSE (
    echo Virtual environment already exists.
)

echo.
echo [2] Activating virtual environment...
call venv\Scripts\activate.bat

echo.
echo [3] Installing required Python packages...
pip install -r requirements.txt

echo.
echo [4] Initializing the SQLite database...
echo NOTE: If a database already exists, it will be recreated.
python init_sqlite.py

echo.
echo =======================================================
echo Setup Complete! 
echo You can now double-click 'run.bat' to start the application.
echo =======================================================
pause
