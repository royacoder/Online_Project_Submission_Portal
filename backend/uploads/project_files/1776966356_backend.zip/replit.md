# Online Project Submission Portal

## Overview

A web-based project management system for academic institutions. Supports a role-based hierarchy (Admin, HOD, Guide, Student) to handle team formations, project submissions, and evaluations.

## Tech Stack

- **Backend**: Python 3 with Flask
- **Database**: SQLite (local) / PostgreSQL (production via DATABASE_URL env var)
- **Authentication**: Session-based (flask-session) with bcrypt password hashing
- **File Storage**: Local (`backend/uploads/`) with optional Cloudinary cloud storage
- **Package Manager**: pip

## Project Layout

- `backend_clone/app.py` - Main Flask application (REST API, ~2900 lines)
- `backend_clone/init_sqlite.py` - Database initialization script
- `backend_clone/portal.db` - SQLite database (created on first run)
- `backend_clone/requirements.txt` - Python dependencies
- `backend/uploads/` - File upload directories (project_files, profile_photos)
- `database/` - SQL schema files for MySQL/SQLite and PostgreSQL
- `flask_session/` - Filesystem session storage

## Running the App

The Flask app runs on port 5000 via the "Start application" workflow:
```
cd backend_clone && python3 app.py
```

## Default Admin Credentials

- Email: `admin@portal.com`
- Password: `admin123`

## Key Configuration (Environment Variables)

- `DATABASE_URL` - PostgreSQL connection string (if not set, uses SQLite)
- `SECRET_KEY` - Flask session secret key
- `CORS_ORIGINS` - Allowed CORS origins (default: `http://localhost:3000`)
- `CLOUDINARY_ENABLED` - Enable Cloudinary file storage (`true`/`false`)
- `CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY`, `CLOUDINARY_API_SECRET` - Cloudinary credentials

## User Roles

1. **Admin** - Full system access
2. **HOD** (Head of Department) - Department management
3. **Guide** - Mentor/supervisor for student teams
4. **Student** - Project submission and team management

## Deployment

Configured for autoscale deployment using gunicorn:
```
gunicorn --bind=0.0.0.0:5000 --reuse-port --chdir=backend_clone app:app
```
