# Render Deployment Guide - Flask Backend

Complete step-by-step instructions to deploy your Python Flask backend to Render.

---

## Step 1: Create a Render Account

1. Go to https://render.com
2. Sign up with GitHub (or email)
3. Connect your GitHub account (if not already connected)

---

## Step 2: Create a New Web Service

1. Click **New +** > **Web Service**
2. Select **Deploy an existing repository**
3. Search for and select `royacoder/ProjectSubmissionBackend`
4. Click **Connect**

---

## Step 3: Configure the Web Service

### Basic Information
- **Name:** `ProjectSubmissionBackend` (or any name you prefer)
- **Region:** Choose closest to users (e.g., `Oregon` for US)
- **Branch:** `master`
- **Runtime:** `Python 3`

### Build & Deploy Settings
- **Build Command:** `pip install -r requirements.txt`
- **Start Command:** `gunicorn app:app --bind 0.0.0.0:5000`

⚠️ **Important:** Use port `5000` explicitly in the start command (not `$PORT` variable)

Click **Create Web Service** and wait for it to create.

---

## Step 4: Add Environment Variables

Once the service is created:

1. Go to **Settings** tab
2. Scroll to **Environment**
3. Click **Add Environment Variable**

Add these variables (copy from the table below):

### Required Variables

```
SECRET_KEY=9d84fa5b73370f1704f0beb6ffc37890949ae3f574065de41218a0ec0d695a8d
SESSION_COOKIE_SAMESITE=None
SESSION_COOKIE_SECURE=true
CORS_ORIGINS=https://your-vercel-frontend.vercel.app
DATABASE_URL=postgresql://[user]:[password]@[host]:[port]/[database]
DEBUG=false
HOST=0.0.0.0
PORT=5000
```

### Optional: Cloudinary Variables

```
CLOUDINARY_ENABLED=true
CLOUDINARY_CLOUD_NAME=dgaacithe
CLOUDINARY_API_KEY=271363738358446
CLOUDINARY_API_SECRET=lbk4aK48WprtyFpzxOpfxgA98oI
```

### Optional: JWT Variable

```
JWT_SECRET_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJ6aXdqbG9wcmlrbmRtaHhqcmpvIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3NTk2Mjg1NywiZXhwIjoyMDkxNTM4ODU3fQ.GgS94pjjhQ1uGprBvp2u_5kw9o_7FORETcBYKWaQFdg
```

---

## Step 5: Get Database URL from Supabase

1. Go to your Supabase project dashboard
2. Click **Settings** > **Database**
3. Copy the **Connection string** (PostgreSQL URI)
4. It should look like: `postgresql://postgres:password@db.xxx.supabase.co:5432/postgres`
5. Paste this as `DATABASE_URL` in Render

---

## Step 6: Update CORS_ORIGINS

Before deploying the frontend to Vercel, you can use a placeholder.

Later, when you deploy to Vercel:
1. Get your Vercel frontend URL (e.g., `https://myapp.vercel.app`)
2. Update `CORS_ORIGINS` in Render:
   - Go to **Settings** > **Environment**
   - Edit `CORS_ORIGINS`
   - Replace with your actual Vercel URL
   - Save and redeploy

---

## Step 7: Deploy Database Schema

Before the backend can work, you need to create the database tables in Supabase:

1. Go to your Supabase project
2. Click **SQL Editor**
3. Click **New Query**
4. Copy the entire contents of `database/schema_postgres.sql` from your project
5. Paste into the Supabase SQL Editor
6. Click **Run**
7. Wait for the query to complete (all tables should be created)

---

## Step 8: Verify Deployment

1. Go to Render dashboard
2. Click on your **ProjectSubmissionBackend** service
3. Wait for "Deploy in progress" to finish
4. When it says "Live", your backend is running!
5. Your backend URL will be: `https://projectsubmissionbackend.onrender.com` (or similar)

---

## Step 9: Test the Backend

Open in your browser:
```
https://your-render-url.onrender.com/api/health
```

Or use curl:
```powershell
curl https://your-render-url.onrender.com/api/health
```

If you see a response, the backend is working!

---

## Troubleshooting

### Build fails with "ModuleNotFoundError"
- Check that `requirements.txt` exists in `python_backend/`
- Ensure all imports in `app.py` are in `requirements.txt`

### Deployment stuck at "Deploy in progress"
- Check **Logs** tab for errors
- Common issues: Missing `gunicorn` in requirements.txt (should be there)

### Database connection error
- Verify `DATABASE_URL` is correct and currently active in Supabase
- Check that schema has been deployed (run `schema_postgres.sql`)

### CORS errors in frontend
- Make sure `CORS_ORIGINS` includes your Vercel frontend URL
- Use exact URL with `https://` prefix

---

## Next Steps

1. ✅ Deploy backend to Render
2. Deploy database schema to Supabase (Step 7 above)
3. Deploy frontend to Vercel
4. Create `frontend/config.json` with your Render backend URL
5. Test end-to-end functionality

---

## Render Dashboard Quick Links

- **Logs:** View real-time deployment and runtime logs
- **Settings:** Manage environment variables and build settings
- **Events:** Track deployment history and rollbacks
- **Monitoring:** Check uptime and performance

Your backend URL will be available under **Settings** > **General** as the **Render URL**.
